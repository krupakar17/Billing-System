<?php
$name="kavya";
echo '<img src="profile/';
echo $name;
echo '.png">';

?>
